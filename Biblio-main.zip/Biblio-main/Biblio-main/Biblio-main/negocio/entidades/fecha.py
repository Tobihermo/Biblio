class Fecha:
    """
    Representa una fecha con día, mes y año
    """

    def __init__(self, anio: int, mes: int, dia: int):
        self.__anio = anio
        self.__mes = mes
        self.__dia = dia

    def __str__(self):
        return f'{self.__dia}/{self.__mes}/{self.__anio}'

    def validar_fecha(self, anio: int, mes: int, dia: int):
        """
        Valida las fechas que ingresa el usuario
        """
        if not isinstance(anio, int) or not isinstance(mes, int) or not isinstance(dia, int):
            raise TypeError("Error: El año/mes/dia ingresado no son validos")
        if dia > 31 or dia < 0 or mes > 12 or mes < 0:
            raise ValueError("Error: Mes o dia ingresado fuera de rango")

    @property
    def fecha(self):
        return (self.__dia, self.__mes, self.__anio)

    def __eq__(self, other):
        """
        Compara si dos fechas son iguales
        """
        if isinstance(other, Fecha):
            return (self.__anio == other.__anio and self.__mes == other.__mes and self.__dia == other.__dia)
        return False

    def __lt__(self, other):
        """
        Compara si la fecha actual es menor que la otra
        """
        if isinstance(other, Fecha):
            return (self.__anio < other.__anio or
                    (self.__anio == other.__anio and self.__mes < other.__mes) or
                    (self.__anio == other.__anio and self.__mes == other.__mes and self.__dia < other.__dia))
        return False

    def __le__(self, other):
        """
        Compara si la fecha actual es menor o igual que la otra
        """
        return self < other or self == other

    def __gt__(self, other):
        """
        Compara si la fecha actual es mayor que la otra
        """
        if isinstance(other, Fecha):
            return not self <= other
        return False

    def __ge__(self, other):
        """
        Compara si la fecha actual es mayor o igual que la otra
        """
        return not self < other
