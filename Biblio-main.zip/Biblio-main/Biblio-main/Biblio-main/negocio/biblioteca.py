import datetime
from negocio.entidades.libro import Libro
from negocio.entidades.fecha import Fecha
from negocio.entidades.usuarios.usuario import Usuario
from negocio.entidades.reserva import Reserva
from persistencia.librodao import LibroDAO
from persistencia.usuariodao import UsuarioDAO
from persistencia.reservadao import ReservaDAO


class Biblioteca:
    """
    Maneja la biblioteca, tomando acciones sobre los libros en el DAO
    """

    def __init__(self):
        self.libro_dao = LibroDAO()
        self.usuario_dao = UsuarioDAO()
        self.prestamo_dao = ReservaDAO()

    def agregar_libro(self, libro: Libro):
        """"""""
        self.libro_dao.agregar_libro(libro)

    def eliminar_libro(self, id_libro: int):
        """"""
        self.libro_dao.eliminar_libro(id_libro)

    def buscar_libro_por_id(self, id_libro: int):
        """"""
        libro_data = self.libro_dao.obtener_libro(id_libro)
        if libro_data:
            return Libro(
                libro_data["id_libro"],
                libro_data["nombre"],
                libro_data["autor"],
                libro_data["categoria"],
                libro_data["estado"],
                libro_data["id_estanteria"],
                libro_data["id_estante"],
                libro_data["nivel_acceso"]
            )
        return None

    def prestar_libro(self, id_libro: int, id_usuario: int):
        """"""
        libro = self.buscar_libro_por_id(id_libro)
        usuario = self.usuario_dao.obtener_usuario(id_usuario)
        if libro and usuario:
            if libro.estado == "disponible":
                fecha_reserva = Fecha(datetime.datetime.now(
                ).year, datetime.datetime.now().month, datetime.datetime.now().day)

                # Crea la fecha de devolución como un objeto
                fecha_devolucion = Fecha((datetime.datetime.now() + datetime.timedelta(days=7)).year,
                                         (datetime.datetime.now() +
                                          datetime.timedelta(days=7)).month,
                                         (datetime.datetime.now() + datetime.timedelta(days=7)).day)
                # Crea la reserva
                id_reserva = self._generar_id_reserva()
                reserva = Reserva(id_reserva, id_libro,
                                  id_usuario, fecha_reserva, fecha_devolucion)

                self.prestamo_dao.agregar_reserva(reserva)

                self.libro_dao.actualizar_estado(id_libro, "prestado")

                return True
        return False

    def devolver_libro(self, id_libro: int):
        """"""
        libro = self.buscar_libro_por_id(id_libro)
        if libro:
            reservas = self.prestamo_dao.listar_reservas()
            for reserva in reservas:
                if reserva.id_libro == id_libro and reserva.fecha_devolucion > Fecha(datetime.datetime.now().year, datetime.datetime.now().month, datetime.datetime.now().day):
                    self.prestamo_dao.eliminar_reserva(reserva.id_reserva)
                    break
            self.libro_dao.actualizar_estado(id_libro, "disponible")
            return True
        return False

    def listar_libros(self):
        """"""
        libros_data = self.libro_dao.listar_libros()
        return [
            Libro(
                libro["id_libro"],
                libro["nombre"],
                libro["autor"],
                libro["categoria"],
                libro["estado"],
                libro["id_estanteria"],
                libro["id_estante"],
                libro["nivel_acceso"]
            ) for libro in libros_data
        ]

    def listar_usuarios(self):
        """"""
        usuarios_data = self.usuario_dao.listar_usuarios()
        return [
            Usuario(usuario["id_usuario"], usuario["nombre"], usuario["tipo"])
            for usuario in usuarios_data
        ]

    def _generar_id_reserva(self):
        """
        Genera un nuevo ID de reserva basado en el mayor ID existente en la base de datos
        """
        reservas = self.prestamo_dao.listar_reservas()
        if reservas:
            return max([reserva.id_reserva for reserva in reservas]) + 1
        return 1
