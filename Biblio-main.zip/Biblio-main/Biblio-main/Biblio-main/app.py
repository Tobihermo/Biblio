from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from negocio.entidades.reserva import Reserva
from negocio.entidades.usuarios.estudiante import Estudiante
from negocio.entidades.usuarios.profesor import Profesor
from persistencia.reservadao import ReservaDAO
from negocio.entidades.fecha import Fecha
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# que es estooooooo

reserva_dao = ReservaDAO()


@app.route("/", methods=["GET", "POST"])
def index():
    query = request.form.get("query", "")
    nivel_acceso = int(request.form.get("nivel_acceso", 1))

    # Obtiene libros disponibles según el nivel de acceso
    libros = reserva_dao.obtener_libros_disponibles(nivel_acceso)

    return render_template("index.html", query=query, libros=libros)


@app.route("/reservar", methods=["GET", "POST"])
def reservar():
    if request.method == "POST":
        id_libro = request.form.get("id_libro")
        id_usuario = request.form.get("id_usuario")
        tipo_usuario = request.form.get("tipo_usuario")

        # Valida entradas
        if not id_libro or not id_usuario or not tipo_usuario:
            flash("Todos los campos son obligatorios.", "danger")
            return redirect(url_for("reservar"))

        # Crear usuario según el tipo
        if tipo_usuario == "estudiante":
            usuario = Estudiante(int(id_usuario), "Nombre del Estudiante")
        elif tipo_usuario == "profesor":
            usuario = Profesor(int(id_usuario), "Nombre del Profesor")
        else:
            flash("Tipo de usuario no válido.", "danger")
            return redirect(url_for("reservar"))

        # Crear reserva con fechas usando la clase Fecha
        fecha_reserva = Fecha(datetime.now().year,
                              datetime.now().month, datetime.now().day)
        fecha_devolucion = Fecha((datetime.now() + timedelta(days=7)).year,
                                 (datetime.now() + timedelta(days=7)).month,
                                 (datetime.now() + timedelta(days=7)).day)

        reserva = Reserva(None, int(id_libro), int(
            id_usuario), fecha_reserva, fecha_devolucion)

        try:
            reserva_dao.agregar_reserva(reserva)
            flash("Reserva realizada con éxito.", "success")
        except Exception as e:
            flash(f"Error al realizar la reserva: {e}", "danger")

        return redirect(url_for("index"))

    libros = reserva_dao.obtener_libros_disponibles(
        nivel_acceso=1  # Nivel de acceso por defecto: 1
    )
    return render_template("reservas.html", libros=libros)


@app.route("/devolver/<int:id_reserva>", methods=["POST"])
def devolver(id_reserva):
    try:
        reserva_dao.devolver_libro(id_reserva)
        flash("Libro devuelto correctamente.", "success")
    except ValueError as ve:
        flash(str(ve), "danger")
    except Exception as e:
        flash(f"Error al devolver el libro: {e}", "danger")

    return redirect(url_for("index"))


@app.route("/historial", methods=["GET"])
def historial():
    try:
        reservas = reserva_dao.listar_reservas()
    except Exception as e:
        flash(f"Error al obtener el historial: {e}", "danger")
        reservas = []

    return render_template("historial.html", reservas=reservas)


if __name__ == "__main__":
    app.run(debug=True)
