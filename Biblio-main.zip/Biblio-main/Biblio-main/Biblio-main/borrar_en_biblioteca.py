import sqlite3


class BorrarEnBiblioteca:
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()

    def __del__(self):
        """
        Cerrar la conexión cuando la instancia de la clase se elimine
        """
        self.conn.close()

    def borrar_libro(self, id_libro):
        """
        Borra un libro de la base de datos
        """
        self.cursor.execute(
            'SELECT * FROM usuario WHERE id_usuario = ?', (id_libro,))
        libro = self.cursor.fetchone()

        if libro:
            print(f"\nLibro encontrado: {libro}")
            confirmacion = input(
                "¿Está seguro de que desea borrar este libro? (s/n): ")

            if confirmacion.lower() == 's':
                self.cursor.execute(
                    'DELETE FROM usuario WHERE id_usuario = ?', (id_libro,))
                self.conn.commit()
                print("Libro borrado exitosamente.")
            else:
                print("Operación cancelada.")
        else:
            print("No se encontró un libro con ese ID.")

    def borrar_varios_libros(self, cantidad):
        """
        Permite borrar varios libros en función de la cantidad proporcionada
        """
        for i in range(cantidad):
            print(f"\nBorrando libro {i+1} de {cantidad}...")
            id_libro = int(input("ID del libro: "))
            self.borrar_libro(id_libro)

    def listar_libros(self):
        """
        Lista todos los libros restantes en la base de datos
        """
        self.cursor.execute('SELECT * FROM usuario')
        libros_restantes = self.cursor.fetchall()
        print("\nLibros restantes en la biblioteca:")
        for libro in libros_restantes:
            print(libro)

    def ejecutar(self):
        """
        Método para manejar las interacciones con el usuario
        """
        cantidad_libros = int(input("¿Cuántos libros desea borrar? "))
        self.borrar_varios_libros(cantidad_libros)
        self.listar_libros()
