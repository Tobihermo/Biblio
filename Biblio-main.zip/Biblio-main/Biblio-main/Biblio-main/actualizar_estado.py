import sqlite3
import os


class ActualizarEstado:
    """Gestiona la actualización del estado de los libros"""

    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = None
        self.cursor = None

    def conectar(self):
        """
        Conecta a la base de datos
        """
        if not os.path.exists(self.db_path):
            raise FileNotFoundError(
                f"Error: La base de datos no se encuentra en la ruta {self.db_path}")
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        print(f"La base de datos se encuentra en: {self.db_path}")

    def actualizar_libros(self):
        """
        Actualiza todos los libros que están 'prestados' a 'disponibles'
        """
        if not self.conn:
            raise ConnectionError(
                "Debe conectar a la base de datos antes de realizar esta operación.")

        if not self.cursor:
            raise ConnectionError(
                "No se ha creado un cursor para la base de datos.")

        try:
            self.cursor.execute(
                "UPDATE libros SET estado = 'disponible' WHERE estado = 'prestados'"
            )
            self.conn.commit()  # Commit the transaction
            print("Todos los libros han sido actualizados a 'disponible'.")
        except sqlite3.Error as e:
            print(
                f"Ocurrió un error al intentar actualizar la base de datos: {e}")

    def cerrar_conexion(self):
        """"""
        if self.conn:
            self.conn.close()
