# persistencia/basededatos.py
import sqlite3


class ConexionDb:
    """
    Clase encargada de gestionar las conexiones y consultas a la base de datos
    """

    def __init__(self, db_path: str):
        self.db_path = db_path

    def get_db(self):
        """
        Retorna una conexión a la base de datos
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def obtener_usuario_por_tipo(self, tipo):
        """
        Obtiene un usuario por su tipo (estudiante / profesor)
        """
        with self.get_db() as conn:
            usuario = conn.execute(
                'SELECT * FROM usuarios WHERE tipo = ?', (tipo,)).fetchone()
            return usuario

    def obtener_libros_disponibles(self, nivel_acceso):
        """
        Obtiene los libros disponibles según el nivel de acceso
        """
        with self.get_db() as conn:
            libros = conn.execute(''' 
                SELECT * FROM biblioteca 
                WHERE estado = "disponible" AND nivel_acceso <= ?
            ''', (nivel_acceso,)).fetchall()
            return libros
